# FINAL AUTHORITY REPORT

repository: leegahuyn/mathlib4
final branch: gpt/final-authority-batch-v7-20260820
tested source commit: 8f7e861f5f76c0aa5d347e0de865516a1ba23922
GitHub Actions run: 32443566530
GitHub Actions URL: https://github.com/leegahuyn/mathlib4/actions/runs/32443566530

Lean version: Lean (version 4.33.0-rc1, x86_64-unknown-linux-gnu, commit 62eed1db4d67327ec8120be05f1a1b0847d74561, Release)
Lake version: Lake version 5.0.0-src+62eed1d (Lean version 4.33.0-rc1)
Pinned toolchain: leanprover/lean4:v4.33.0-rc1
lake-manifest SHA256: 672474eb93bc14c66cd1ff45203c451987fe525f7b5d13ecd83140be46434b26

Mock2:
  PASS

Mock2_Advanced:
  PASS

Mock2_FunctionalAnalysis:
  status: TRUE PASS
  blob: 28f614d48e02a0f28d3f5a758e813350b3ea89cf
  sha256: c680a35b9f12ea3223d8328ed0f5f0674b3439e650bb62cb900b54917f9653bd
  direct Lean exit: 0
  errors: 0

Integrated:
  status: PASS
  blob: 464f5dd095876b20165d12690c8127ef9d909e6a
  sha256: a77f9e67980ec35b0d7b4d1624c10ec68051f575468d3b74859e6cf30e3e0439
  direct Lean exit: 0
  errors: 0

QYM:
  status: NOT VERIFIED
  canonical replay: NOT_RUN
  blob: 7afb309d7c4da97da7bc6b922931734d72830d41
  sha256: ab7c394f68b812046bcfae109b274a2d4fa42479bf8e76461c73a9c190fb3204
  direct Lean exit: NOT RUN
  error_headers: NOT RUN
  warnings: NOT RUN
  panic: NOT RUN
  forbidden: 0
  olean: NOT RUN
  ilean: NOT RUN

Mock3:
  canonical path: PrimalitySheafVerification/Mock3.lean
  blob: NOT RUN
  sha256: NOT RUN
  direct Lean exit: NOT RUN
  errors: NOT RUN

Final13:
  root count: 13
  PASS: 13
  FAIL: 0
  SKIPPED: 0
  NOT RUN: 0

BuildAll:
  exit: 0
  errors: 0
  skipped required targets: 0

Clean build #1:
  PASS

Clean build #2:
  PASS

15-checklist:
  PASS: 7
  FAIL: 8
  NOT RUN: 0
  SKIPPED: 0

final first Lean error:
  NONE

final blocker:
  NONE

last completed authority gate:
  QYM golden locked

next incomplete gate:
  QYM independent canonical replay

QYM golden source unchanged:
  YES

all PASS evidence source-identical:
  YES

warnings:
  counted, preserved, and classified under the current GB0 authority policy; not silently discarded

FINAL AUTHORITY:
  NOT COMPLETE
